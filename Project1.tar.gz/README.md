I believe I finished the entire project. It was hard for me to test on the rinkeby network, because I used very small amounts of wei. I fixed this by using more with the web application. It does seem to be working correctly though.

FILES
-----------
AccountsAfter.png:
    This is the Metamask account before the auction.

AccountsBefore.png:
    This is the Metamask account after the auction.

DuringAuctionDapp.png:
    This is the oneclickdapp during the auction with number of bidders.

AfterAuctionDapp.png:
    This is the oneclickdapp after the auction with contract balance.

auction.sol:
    This is the solidity code used.

README.md:
    This file.
